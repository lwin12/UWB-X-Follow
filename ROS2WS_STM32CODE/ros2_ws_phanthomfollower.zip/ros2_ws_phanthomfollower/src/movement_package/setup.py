from setuptools import setup

package_name = 'movement_package'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    py_modules=['movement_package.movement_node'],
    install_requires=['setuptools', 'rclpy'],
    entry_points={
        'console_scripts': [
            'movement_node = movement_package.movement_node:main',
        ],
    },
)

