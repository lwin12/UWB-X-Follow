#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import UInt32, String
from geometry_msgs.msg import Twist

class Talker(Node):
    def __init__(self):
        super().__init__('talker_node')

        # Initialize with default value to avoid AttributeError
        #self.STM32_input = "start"

        # Initialization routines
        #self.initialize("start")
        #self.publish_mode("sit")

        # Subscriber setup
        self.subscription = self.create_subscription(
            String,
            '/stm32_input',
            self.listener_callback,
            10
        )

    def listener_callback(self, msg):
        self.STM32_input = msg.data
        print(self.STM32_input)

        self.initialize(self.STM32_input)

        if self.STM32_input in ["sit", "walk"]:
            self.publish_mode(self.STM32_input)
        elif self.STM32_input in ["forward", "backward", "strafe_left", "strafe_right", "turn_left", "turn_right"]:
            self.publish_movement(self.STM32_input)

    def initialize(self, STM32_input):
        self.STM32_input = STM32_input

        if STM32_input == "start":
            self.topic = "/command/setControlMode"
            self.publisher_UInt32 = self.create_publisher(UInt32, self.topic, 10)
            self.publish_init(140)

            self.topic = "/command/setAction"
            self.publisher_UInt32 = self.create_publisher(UInt32, self.topic, 10)
            self.publish_init(2)

            self.topic = "/command/setVisionMode"
            self.publisher_UInt32 = self.create_publisher(UInt32, self.topic, 10)
            self.publish_init(2)

            self.topic = "/mcu/command/manual_twist"
            self.publisher_Twist = self.create_publisher(Twist, self.topic, 10)

    def publish_mode(self, STM32_input):
        self.STM32_input = STM32_input

        if STM32_input == "sit":
            self.topic = "/command/setAction"
            self.publisher_UInt32 = self.create_publisher(UInt32, self.topic, 10)
            self.publish_init(0)

        elif STM32_input == "walk":
            self.topic = "/command/setAction"
            self.publisher_UInt32 = self.create_publisher(UInt32, self.topic, 10)
            self.publish_init(2)

            self.topic = "/mcu/command/manual_twist"
            self.publisher_Twist = self.create_publisher(Twist, self.topic, 10)

    def publish_init(self, input_data):
        msg = UInt32()
        msg.data = input_data
        self.get_logger().info(
            f'STM32_input = {self.STM32_input} | Publishing on {self.topic}: {msg.data}'
        )
        self.publisher_UInt32.publish(msg)

    def publish_movement(self, input_data):
        msg = Twist()
        if input_data == "forward":
            msg.linear.x = 1.0
        elif input_data == "backward":
            msg.linear.x = -0.0
        elif input_data == "strafe_right":
            msg.linear.y = -0.5
        elif input_data == "strafe_left":
            msg.linear.y = 0.5
        elif input_data == "turn_right":
            msg.angular.z = -1.0
        elif input_data == "turn_left":
            msg.angular.z = 1.0

        self.get_logger().info(
            f'Input={self.STM32_input} | Topic={self.topic} | '
            f'linear=({msg.linear.x},{msg.linear.y},{msg.linear.z}) | '
            f'angular=({msg.angular.x},{msg.angular.y},{msg.angular.z})'
        )
        self.publisher_Twist.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = Talker()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

