from setuptools import setup

package_name = 'serial_package'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    py_modules=['serial_package.serial_node'],
    install_requires=['setuptools', 'rclpy', 'pyserial'],
    entry_points={
        'console_scripts': [
            'serial_node = serial_package.serial_node:main',
        ],
    },
)
