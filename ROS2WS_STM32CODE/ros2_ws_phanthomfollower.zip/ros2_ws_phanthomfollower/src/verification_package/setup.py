from setuptools import setup

package_name = 'verification_package'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    py_modules=['verification_package.verification_node'],
    install_requires=['setuptools', 'rclpy'],
    entry_points={
        'console_scripts': [
            'verification_node = verification_package.verification_node:main',
        ],
    },
)
